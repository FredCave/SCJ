	<script async type="text/javascript" src="<?php bloginfo("template_url"); ?>/js/custom.js"></script>

	<?php wp_footer(); ?>

	</body>
</html>