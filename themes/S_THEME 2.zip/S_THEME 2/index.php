<?php get_header(); ?>

	<div id="debug" class="hide">
	</div>

	<!-- GRADIENTS -->
	<div id="gradient" class="">
	</div>
	
	<!-- PDFs -->
	<?php /*include( "includes/pdf.php" );*/ ?>

	<!-- INFO -->
	<?php include( "includes/info.php" ); ?>
	
	<!-- IMAGES -->
	<?php include( "includes/images.php" ); ?>

<?php get_footer(); ?>